package com.example.calendarium

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()
    }

    private fun initView() {

    }

    private fun Login() {
//        TODO("Not yet implemented")
        setContentView(R.layout.activity_log_in)

    }

    private fun SignUp() {

        setContentView(R.layout.activity_sign_up)

        }

    private fun clearEditText()
    {

    }
}